"""
This is a boilerplate pipeline 'create_model'
generated using Kedro 0.18.11
"""
from kedro.pipeline import Pipeline, node, pipeline

from .nodes import load_data, train_1, train_2, store_artifacts_to_mlflow

def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=load_data,
                inputs=None,
                outputs=["df", "importance_df", "features"],
                name="load_data_node",
            ),
            node(
                func=train_1,
                inputs=["df", "importance_df", "features"],
                outputs=["model_1", "importance_1"],
                name="train_1_node",
            ),
            node(
                func=train_2,
                inputs=["df", "importance_df", "features"],
                outputs=["model_2", "importance_2"],
                name="train_2_node",
            ),
            node(
                func=store_artifacts_to_mlflow,
                inputs=["importance_1", "importance_2"],
                outputs=None,
                name="store_artifacts_to_mlflow_node",
            )
        ]
    )
