"""
This is a boilerplate pipeline 'create_model'
generated using Kedro 0.18.11
"""
import random
from typing import Any, Dict, Tuple, List

import pandas as pd
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler,LabelEncoder
from catboost import CatBoostClassifier
from catboost import CatBoostRegressor
from catboost import Pool

import mlflow


def load_data() -> Tuple[pd.DataFrame, pd.DataFrame, List]:
  """1つめのノード


  """
  # mlflowの実験管理の開始
  # TODO（検討）：mlflowの実験IDとGitのソースコードをどう紐づけるべきか
  # TODO（検討）：作成したパイプラインを全て実施する場合は問題ない。
  #  ただ、例えばこちらのノードの実行がされず別のノード単体で実施される場合、mlflowが保存されないケースが出てくる。
  # TODO：mlrunsディレクトリが現状、このnode.pyの配下に作成されている
  #  data/99_mlflow配下にmlrunsディレクトリが作成されるようにしたい。
  #  mlflow.set_tracking_uri(uri: Union[str, pathlib.Path]) → Noneの使用が必要か。
  #  https://mlflow.org/docs/latest/python_api/mlflow.html#mlflow.set_tracking_uri
  mlflow.start_run()

  diabetes = datasets.load_diabetes()
  df = pd.DataFrame(diabetes.data, columns=("age", "sex", "bmi", "map", "tc", "ldl", "hdl", "tch", "ltg", "glu"))
  df['target'] = diabetes.target
  df['target_class']=0
  df['target_class']=np.where(df['target']>211.5,1,0)#分類用に目的変数を作成している。

  features=[c for c in df.columns if c not in ['target','target_class']]
  # print(set(df['target']))
  # print(set(df['target_class']))

  importance_df=pd.DataFrame(index=df[features].columns)

  return df, importance_df, features

def train_1(df: pd.DataFrame, importance_df: pd.DataFrame, features: List) -> Tuple[Any, pd.DataFrame, pd.DataFrame]:
  """2つめのノード


  """
  fold=3
  sfk=StratifiedKFold(n_splits=fold, shuffle=True, random_state=2)
  for i ,(tr_index,va_index) in enumerate(sfk.split(df,df['target_class'])):
    tr_x,tr_y=df[features].iloc[tr_index],df['target_class'].iloc[tr_index]
    va_x,va_y=df[features].iloc[va_index],df['target_class'].iloc[va_index]
    tr_set=Pool(tr_x,label=tr_y)
    va_set=Pool(va_x,label=va_y)
    model=CatBoostClassifier(iterations=100000,random_state=2,nan_mode='Min',eval_metric='AUC')#,task_type='GPU')
    model.fit(tr_set,eval_set=[va_set],verbose_eval =1000,use_best_model=True,early_stopping_rounds=500)

    # mlflowへパラメータとして保存
    # TODO：mlflow.log_paramsメソッドでパラメータをdictで渡して一気に処理出来るのが理想
    mlflow.log_param("leaning_rate_in_train_1", 3)
    mlflow.log_param("random_seed_in_train_1", 5)

    importance_df['importance']=model.feature_importances_/fold
    importance_df.sort_values('importance',inplace=True,ascending=False)
  # モデルのパラメータをmlflowのじっけん
  importance_df.reset_index(inplace=True)
  # importance_df
  return model, importance_df


# importance_df=pd.DataFrame(index=df[features].columns)

def train_2(df: pd.DataFrame, importance_df: pd.DataFrame, features: List) -> Tuple[Any, pd.DataFrame, pd.DataFrame]:
  """3つめのノード

  """

  fold=3
  sfk=StratifiedKFold(n_splits=fold, shuffle=True, random_state=2)
  for i ,(tr_index,va_index) in enumerate(sfk.split(df,df['target'])):
    tr_x,tr_y=df[features].iloc[tr_index],df['target'].iloc[tr_index]
    va_x,va_y=df[features].iloc[va_index],df['target'].iloc[va_index]

    model=CatBoostRegressor(iterations=100000,random_state=2,nan_mode='Min',eval_metric='RMSE')#,task_type='GPU')
    model.fit(tr_x,tr_y,eval_set=[(va_x,va_y)],verbose_eval =1000,use_best_model=True,early_stopping_rounds=500)

    # mlflowへパラメータとして保存
    # TODO：mlflow.log_paramsメソッドでパラメータをdictで渡して一気に処理出来るのが理想
    mlflow.log_param("leaning_rate_in_train_2", 1)
    mlflow.log_param("random_seed_in_train_2", 1)

    importance_df['importance']=model.feature_importances_/fold
  importance_df.sort_values('importance',inplace=True,ascending=False)
  importance_df.reset_index(inplace=True)
  importance_df

  # 評価指標の格納（今回はダミーで実装）
  mlflow.log_metric("AUC", random.random())

  return model, importance_df

def store_artifacts_to_mlflow(importance_df_1: pd.DataFrame, importance_df_2: pd.DataFrame):
  """mlflowで管理するartifactを指定

  """
  #  TODO（検討）: ノードはinput, outputのいずれかは必要なため、input/outputを使用せずにmlflowに結果だけ最後に保存場合、
  #   無駄に引数を設定する必要がある。
  mlflow.log_artifact("./data/07_model_output/importance_1.csv")
  mlflow.log_artifact("./data/07_model_output/importance_2.csv")

  # mlflowの実験管理の終了
  mlflow.end_run()


if __name__ == "__main__":
    # kedro関係なしのテスト用
    print("start: load data")
    df, importance_df, features = load_data()
    print("start: train 1")
    train_1(df, importance_df, features)
    print("start: train 2")
    train_2(df, importance_df, features)
    print("start: store_artifacts_to_mlflow")
    store_artifacts_to_mlflow()