"""catboost_test
"""

__version__ = "0.1"
